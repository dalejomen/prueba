﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ibero.Services.Avaya.Domain.Infrastructure.Abstract
{
     public class AvayaAppOption
    {
        public string UriAvaya { get; set; }

    }
}
