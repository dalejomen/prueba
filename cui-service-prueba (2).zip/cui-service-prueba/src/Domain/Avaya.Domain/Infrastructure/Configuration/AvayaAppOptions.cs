﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ibero.Services.Avaya.Domain.Infrastructure.Configuration
{
    public class AvayaAppOptions
    {

    }
}
