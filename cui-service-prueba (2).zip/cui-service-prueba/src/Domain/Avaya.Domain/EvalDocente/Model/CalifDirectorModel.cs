﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ibero.Services.Avaya.Domain.EvalDocente.Model
{
     public class CalifDirectorModel
    {
		public string idBannerDocente { get; set; }
		public string periodo { get; set; }
		public string codigoPrograma { get; set; }
		public string materia { get; set; }
		public string ncr { get; set; }
		public string calfEst { get; set; }
		public string PromRespuesta { get; set; }
	}
}
