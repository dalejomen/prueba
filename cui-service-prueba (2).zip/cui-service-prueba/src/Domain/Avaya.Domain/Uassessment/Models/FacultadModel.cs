﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ibero.Services.Avaya.Domain.Uassessment.Models
{
    public class FacultadModel
    {       
        public int Id { get; set; }
        public string Id_facultad { get; set; }
        public string Codigo_Facultad { get; set; }
        public string Nombre_facultad { get; set; }
        public string Id_institucion { get; set; }
    }

   
}
