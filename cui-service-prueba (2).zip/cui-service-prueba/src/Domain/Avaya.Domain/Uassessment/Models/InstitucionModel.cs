﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ibero.Services.Avaya.Domain.Uassessment.Models
{
    public class InstitucionModel
    {       
        public int Id_Institucion { get; set; }
        public string Nombre_institucion { get; set; }
 
    }

   
}
