﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ibero.Services.Avaya.Domain.Banner.Models
{
    public class GradeAprovPersonModel
    {
        public string StatusGrade { get; set; }
    }
}
