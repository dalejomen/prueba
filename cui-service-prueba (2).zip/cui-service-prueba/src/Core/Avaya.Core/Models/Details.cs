﻿namespace Ibero.Services.Avaya.Core.Models
{

    using System;
    using System.Collections.Generic;
    using System.Text;


    public class Details
    {
        public string output { get; set; }
        public string output_type { get; set; }
        public string id { get; set; }
    }
}
